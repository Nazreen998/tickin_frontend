// ignore_for_file: curly_braces_in_flow_control_structures

class SlotRules {
  final double maxAmount;
  final bool lastSlotEnabled;
  final String lastSlotOpenAfter;

  SlotRules({
    required this.maxAmount,
    required this.lastSlotEnabled,
    required this.lastSlotOpenAfter,
  });

  factory SlotRules.fromMap(Map<String, dynamic> m) {
    final raw = m["maxAmount"] ?? m["threshold"] ?? 80000;

    return SlotRules(
      maxAmount: (raw is num) ? raw.toDouble() : double.tryParse("$raw") ?? 80000,
      lastSlotEnabled: m["lastSlotEnabled"] == true,
      lastSlotOpenAfter: m["lastSlotOpenAfter"]?.toString() ?? "17:00",
    );
  }
}

class SlotItem {
  final String pk;
  final String sk;

  final String time;
  final String vehicleType; // FULL / HALF
  final String? pos;
  final String status;

  final String? orderId;

  final String? mergeKey;
  final double? totalAmount;
  final double? amount; 
  final String? tripStatus;

  final double? lat;
  final double? lng;

  final bool blink;

  final String? userId;

  // ✅ NEW IMPORTANT FIELDS
  final String? distributorName;
  final String? distributorCode;
  final String? bookedBy;

  final String? companyCode;
  final String? date;

  final List<dynamic>? participants;
  final double? distanceKm;
  final int? bookingCount;

  SlotItem({
    required this.pk,
    required this.sk,
    required this.time,
    required this.vehicleType,
    required this.status,
    this.pos,
    this.orderId,
    this.amount,
    this.mergeKey,
    this.totalAmount,
    this.tripStatus,
    this.lat,
    this.lng,
    this.blink = false,
    this.userId,
    this.distributorName,
    this.distributorCode,
    this.bookedBy,
    this.companyCode,
    this.date,
    this.participants,
    this.distanceKm,
    this.bookingCount,
  });

  static String normalizeTime(String t) {
    final x = t.trim();
    if (!x.contains(":")) return x;

    final parts = x.split(":");
    final hh = parts[0].padLeft(2, "0");
    final mm = (parts.length > 1 ? parts[1] : "00").padLeft(2, "0");
    return "$hh:$mm";
  }

  factory SlotItem.fromMap(Map<String, dynamic> m) {
    final pk = m["pk"]?.toString() ?? "";
    final sk = m["sk"]?.toString() ?? "";

    String? companyCode;
    String? date;

    try {
      final parts = pk.split("#");
      final cIdx = parts.indexOf("COMPANY");
      final dIdx = parts.indexOf("DATE");
      if (cIdx != -1 && cIdx + 1 < parts.length) companyCode = parts[cIdx + 1];
      if (dIdx != -1 && dIdx + 1 < parts.length) date = parts[dIdx + 1];
    } catch (_) {}

    final rawLat = m["lat"];
    final rawLng = m["lng"];

    final rawTime = (m["time"] ?? m["slotTime"] ?? m["slot_time"])?.toString() ?? "";
    var parsedTime = normalizeTime(rawTime);

    if ((parsedTime.isEmpty || parsedTime == "00:00") && sk.startsWith("MERGE_SLOT#")) {
      try {
        final parts = sk.split("#");
        if (parts.length > 1) parsedTime = normalizeTime(parts[1]);
      } catch (_) {}
    }

    final rawStatus = (m["status"] ?? "AVAILABLE").toString();

    return SlotItem(
      pk: pk,
      sk: sk,

      time: parsedTime,
      vehicleType: (m["vehicleType"] ?? "FULL").toString(),
      pos: m["pos"]?.toString(),
      status: rawStatus,

      orderId: m["orderId"]?.toString(),

      mergeKey: m["mergeKey"]?.toString(),
      totalAmount: (m["totalAmount"] is num)
          ? (m["totalAmount"] as num).toDouble()
          : (m["amount"] is num ? (m["amount"] as num).toDouble() : null),
      amount: (m["amount"] is num)
    ? (m["amount"] as num).toDouble()
    : double.tryParse("${m["amount"]}"),

      tripStatus: m["tripStatus"]?.toString(),

      lat: (rawLat is num) ? rawLat.toDouble() : double.tryParse("$rawLat"),
      lng: (rawLng is num) ? rawLng.toDouble() : double.tryParse("$rawLng"),

      blink: m["blink"] == true,
      userId: m["userId"]?.toString(),

      // ✅ NEW
      distributorName: m["distributorName"]?.toString(),
      distributorCode: m["distributorCode"]?.toString(),
      bookedBy: m["bookedBy"]?.toString(),

      companyCode: companyCode,
      date: date,

      participants: (m["participants"] is List) ? (m["participants"] as List) : [],
      distanceKm: (m["distanceKm"] is num)
          ? (m["distanceKm"] as num).toDouble()
          : double.tryParse("${m["distanceKm"]}"),
      bookingCount: (m["bookingCount"] is num)
          ? (m["bookingCount"] as num).toInt()
          : int.tryParse("${m["bookingCount"]}"),
    );
  }

  bool get isFull => vehicleType.toUpperCase() == "FULL";
  bool get isMerge => sk.startsWith("MERGE_SLOT#");

  String get normalizedStatus {
    final s = status.toUpperCase();
    if (s == "CONFIRMED") return "BOOKED";
    return s;
  }

  // inside SlotItem class

bool get isBooked => normalizedStatus == "BOOKED";
bool get isAvailable => normalizedStatus == "AVAILABLE";

String get displayTime => time.isEmpty ? "--:--" : time;
int get slotIdNum {
  // FULL slots only
  // 09:00 -> 3001-3004 (A,B,C,D)
  // 12:30 -> 3005-3008
  // 16:00 -> 3009-3012
  // 20:00 -> 3013-3016

  final t = time.trim();
  int base = 3001;

  if (t == "09:00") base = 3001;
  else if (t == "12:30") base = 3005;
  else if (t == "16:00") base = 3009;
  else if (t == "20:00") base = 3013;

  final p = (pos ?? "A").toUpperCase();
  int offset = 0;

  if (p == "A") offset = 0;
  if (p == "B") offset = 1;
  if (p == "C") offset = 2;
  if (p == "D") offset = 3;

  return base + offset;
}

String get slotIdLabel => slotIdNum.toString();


}
