// ignore_for_file: deprecated_member_use

import 'dart:convert';
import 'package:flutter/material.dart';

import '../app_scope.dart';
import 'slots/slot_booking_screen.dart';
import 'order_details_screen.dart';

class ManagerOrdersWithSlotScreen extends StatefulWidget {
  const ManagerOrdersWithSlotScreen({super.key});

  @override
  State<ManagerOrdersWithSlotScreen> createState() =>
      _ManagerOrdersWithSlotScreenState();
}

class _ManagerOrdersWithSlotScreenState
    extends State<ManagerOrdersWithSlotScreen> {
  bool loading = false;
  bool _loadedOnce = false;

  // ✅ all orders
  List<Map<String, dynamic>> orders = [];

  // ✅ status filter: ALL / CONFIRMED / PENDING ...
  String selectedStatus = "ALL";

  // ✅ manager locationId (POS)
  String locationId = "";

  // ✅ threshold rules
  // You can change these values anytime.
  static const double fullTruckAmountThreshold = 50000; // ₹50,000
  static const int fullTruckQtyThreshold = 60;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_loadedOnce) {
      _loadedOnce = true;
      _initAndLoad();
    }
  }

  void toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _initAndLoad() async {
    try {
      final scope = TickinAppScope.of(context);
      final userJson = await scope.tokenStore.getUserJson();
      if (userJson != null && userJson.isNotEmpty) {
        final u = jsonDecode(userJson) as Map<String, dynamic>;
        locationId =
            (u["locationId"] ?? u["pos"] ?? u["location"] ?? "").toString();
      }
    } catch (_) {}
    await _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final scope = TickinAppScope.of(context);

      // ✅ Manager allowed: /api/orders/all
      final res = await scope.ordersApi.all(
        status: selectedStatus == "ALL" ? null : selectedStatus,
      );

      final raw = res["orders"] ?? res["items"] ?? res["data"] ?? res;
      final list = raw is List ? raw : (raw is Map ? (raw["orders"] ?? raw["items"] ?? raw["data"] ?? []) : []);


      setState(() {
        orders =
            list.whereType<Map>().map((e) => e.cast<String, dynamic>()).toList();

        // ✅ Latest first (if createdAt exists)
        orders.sort((a, b) {
          final atA = (a["createdAt"] ?? a["created_at"] ?? "").toString();
          final atB = (b["createdAt"] ?? b["created_at"] ?? "").toString();
          return atB.compareTo(atA);
        });
      });
    } catch (e) {
      toast("❌ Load failed: $e");
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String _safe(Map o, List<String> keys) {
    for (final k in keys) {
      final v = o[k];
      if (v != null && v.toString().trim().isNotEmpty) return v.toString();
    }
    return "-";
  }

  num _num(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    return num.tryParse(v.toString()) ?? 0;
  }

  int _calcTotalQty(Map order) {
    final items = (order["items"] ?? order["orderItems"] ?? []) as List;
    int total = 0;
    for (final it in items) {
      if (it is Map) {
        total += (_num(it["qty"] ?? it["quantity"])).toInt();
      }
    }
    return total;
  }

  bool _isSlotBooked(Map order) {
    // ✅ if backend stores slot info
    final slot = order["slot"];
    final slotTime = order["slotTime"];
    final slotDate = order["slotDate"];
    if (slot != null) return true;
    if (slotTime != null && slotTime.toString().isNotEmpty) return true;
    if (slotDate != null && slotDate.toString().isNotEmpty) return true;
    return false;
  }

  String _vehicleType(Map order) {
    final amount = _num(order["amount"] ?? order["totalAmount"] ?? order["grandTotal"]).toDouble();
    final qty = _calcTotalQty(order);

    // ✅ rule: if amount big OR qty big => FULL_TRUCK
    if (amount >= fullTruckAmountThreshold || qty > fullTruckQtyThreshold) {
      return "FULL_TRUCK";
    }
    return "HALF_TRUCK";
  }

  Future<void> _openSlotBooking(Map order) async {
    final orderId = _safe(order, ["orderId", "id"]);
    final distCode = _safe(order, ["distributorId", "distributorCode"]);
    final distName = _safe(order, ["distributorName", "agencyName"]);
    final amount =
        _num(order["amount"] ?? order["totalAmount"] ?? order["grandTotal"])
            .toDouble();

    if (orderId == "-" || orderId.isEmpty) {
      toast("orderId missing");
      return;
    }

    if (distCode == "-" || distCode.isEmpty) {
      toast("distributorCode missing");
      return;
    }

    if (locationId.isEmpty) {
      toast("Manager locationId missing (pos)");
      return;
    }

    final vType = _vehicleType(order);

    // ✅ open slot booking screen
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SlotBookingScreen(
          role: "MANAGER",
          distributorCode: distCode,
          distributorName: distName,
          orderId: orderId,
          amount: amount,
        ),
      ),
    );

    // after slot booking -> refresh list
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("All Orders + Slot Booking (Manager)"),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: Column(
        children: [
          // ✅ Filter bar
          Padding(
            padding: const EdgeInsets.all(12),
            child: DropdownButtonFormField<String>(
              value: selectedStatus,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Status Filter",
              ),
              items: const [
                DropdownMenuItem(value: "ALL", child: Text("ALL")),
                DropdownMenuItem(value: "CONFIRMED", child: Text("CONFIRMED")),
                DropdownMenuItem(value: "PENDING", child: Text("PENDING")),
                DropdownMenuItem(value: "DRAFT", child: Text("DRAFT")),
                DropdownMenuItem(value: "CANCELLED", child: Text("CANCELLED")),
              ],
              onChanged: (v) async {
                if (v == null) return;
                setState(() => selectedStatus = v);
                await _load();
              },
            ),
          ),

          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : orders.isEmpty
                    ? const Center(child: Text("No orders found"))
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          itemCount: orders.length,
                          itemBuilder: (_, i) {
                            final o = orders[i];

                            final orderId = _safe(o, ["orderId", "id"]);
                            final status = _safe(o, ["status"]);
                            final distName = _safe(o, [
                              "distributorName",
                              "agencyName",
                              "distributorId"
                            ]);
                            final amount = _num(o["amount"] ??
                                o["totalAmount"] ??
                                o["grandTotal"]);
                            final createdAt =
                                _safe(o, ["createdAt", "created_at", "date"]);

                            final slotBooked = _isSlotBooked(o);
                            final vType = _vehicleType(o);

                            return Card(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      distName,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text("Order: $orderId"),
                                    Text("Status: $status"),
                                    Text("Date: $createdAt"),
                                    const SizedBox(height: 6),
                                    Text(
                                      "Amount: ₹${amount.toStringAsFixed(2)}   |   Vehicle: $vType",
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(height: 10),

                                    Row(
                                      children: [
                                        OutlinedButton.icon(
                                          icon: const Icon(Icons.receipt_long),
                                          label: const Text("View"),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (_) => OrderDetailsScreen(
                                                    orderId: orderId),
                                              ),
                                            );
                                          },
                                        ),
                                        const Spacer(),

                                        if (!slotBooked)
                                          ElevatedButton.icon(
                                            icon: const Icon(Icons.event_available),
                                            label: const Text("Slot Booking"),
                                            onPressed: () => _openSlotBooking(o),
                                          )
                                        else
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 12, vertical: 8),
                                            decoration: BoxDecoration(
                                              color: Colors.green.shade50,
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              border: Border.all(
                                                  color: Colors.green.shade300),
                                            ),
                                            child: const Text(
                                              "SLOT BOOKED ✅",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
