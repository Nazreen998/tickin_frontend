// ignore_for_file: deprecated_member_use

import 'dart:convert';
import 'package:flutter/material.dart';
import '../../../app_scope.dart';
import '../../models/slot_models.dart';
import '../../widgets/slot_grid.dart';

class SlotBookingScreen extends StatefulWidget {
  final String role; // SALES / DISTRIBUTOR
  final String distributorCode;
  final String distributorName;
  final String orderId;
  final double amount;

  const SlotBookingScreen({
    super.key,
    required this.role,
    required this.distributorCode,
    required this.distributorName,
    required this.orderId,
    required this.amount,
  });

  @override
  State<SlotBookingScreen> createState() => _SlotBookingScreenState();
}

class _SlotBookingScreenState extends State<SlotBookingScreen> {
  bool loading = false;
  bool booking = false;

  String selectedDate = "";
  List<SlotItem> slots = [];
  SlotRules? rules;

  String companyCode = "";

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (selectedDate.isEmpty) {
      selectedDate = _today();
      _init();
    }
  }

  String _today() {
    final now = DateTime.now();
    return "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
  }

  String _tomorrow() {
    final now = DateTime.now().add(const Duration(days: 1));
    return "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
  }

  List<String> allowedDates() => [_today(), _tomorrow()];

  void toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _init() async {
    await _loadCompanyCode();
    await _loadGrid();
  }

  Future<void> _loadCompanyCode() async {
    try {
      final scope = TickinAppScope.of(context);
      final userJson = await scope.tokenStore.getUserJson();
      if (userJson != null && userJson.isNotEmpty) {
        final u = jsonDecode(userJson) as Map<String, dynamic>;
        final cid = (u["companyId"] ?? u["companyCode"] ?? "").toString();
        companyCode = cid.contains("#") ? cid.split("#").last : cid;
      }
    } catch (_) {}
  }

  Future<void> _loadGrid() async {
    setState(() => loading = true);
    try {
      final scope = TickinAppScope.of(context);
      if (companyCode.isEmpty) await _loadCompanyCode();
      if (companyCode.isEmpty) throw Exception("companyCode missing");

      final res =
          await scope.slotsApi.getGrid(companyCode: companyCode, date: selectedDate);

      final rawSlots = (res["slots"] ?? []) as List;
      final rawRules = (res["rules"] ?? {}) as Map;

      final list = rawSlots
          .whereType<Map>()
          .map((e) => SlotItem.fromMap(e.cast<String, dynamic>()))
          .toList();

      // ✅ sales/distributor cannot see DISABLED slots
      final visible = list.where((s) {
        final st = s.normalizedStatus;
        if (st == "DISABLED") return false;
        return s.isFull; // show only FULL grid in this screen
      }).toList();

      setState(() {
        slots = visible;
        rules = SlotRules.fromMap(rawRules.cast<String, dynamic>());
      });
    } catch (e) {
      toast("❌ Grid load failed: $e");
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _bookSlot(SlotItem slot) async {
    setState(() => booking = true);
    try {
      final scope = TickinAppScope.of(context);

      // ⚠ For sales/distributor HALF booking backend requires lat/lng
      // But your backend can resolve lat/lng from distributor final_url
      // so just send no lat/lng, it will fetch from distributor table.

      await scope.slotsApi.book(
        companyCode: companyCode,
        date: selectedDate,
        time: slot.time,
        pos: slot.pos, // FULL booking requires pos
        distributorCode: widget.distributorCode,
        distributorName: widget.distributorName,
        amount: widget.amount,
        orderId: widget.orderId,
      );

      toast("✅ Slot booked");
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      toast("❌ Booking failed: $e");
    } finally {
      if (mounted) setState(() => booking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final maxAmount = rules?.maxAmount ?? 80000;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Slot Booking"),
        actions: [
          DropdownButton<String>(
            value: selectedDate,
            underline: const SizedBox(),
            items: allowedDates()
                .map((d) => DropdownMenuItem(value: d, child: Text(d)))
                .toList(),
            onChanged: (v) {
              if (v == null) return;
              setState(() => selectedDate = v);
              _loadGrid();
            },
          ),
          IconButton(onPressed: _loadGrid, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : booking
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Card(
                        child: ListTile(
                          title: Text("Threshold: ₹${maxAmount.toStringAsFixed(0)}"),
                          subtitle: Text(
                            widget.amount >= maxAmount
                                ? "✅ FULL booking eligible"
                                : "ℹ️ Your booking may go to HALF (merge waiting)",
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: SlotGrid(
                        slots: slots,
                        role: widget.role,
                        myDistributorCode: widget.distributorCode,
                        onSlotTap: (slot) async {
                          if (slot.isBooked) return;

                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text("Book this slot?"),
                              content: Text(
                                  "${slot.time} POS ${slot.pos}\nOrder: ${widget.orderId}"),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context, false),
                                  child: const Text("No"),
                                ),
                                ElevatedButton(
                                  onPressed: () => Navigator.pop(context, true),
                                  child: const Text("Book"),
                                )
                              ],
                            ),
                          );

                          if (ok == true) {
                            await _bookSlot(slot);
                          }
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}
