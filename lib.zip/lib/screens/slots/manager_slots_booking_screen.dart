// ignore_for_file: deprecated_member_use, unused_element

import 'dart:convert';
import 'package:flutter/material.dart';
import '../../app_scope.dart';
import '../../models/slot_models.dart';
import '../../widgets/slot_grid.dart';

class ManagerSlotsBookingScreen extends StatefulWidget {
  final String distributorCode;
  final String distributorName;

  const ManagerSlotsBookingScreen({
    super.key,
    required this.distributorCode,
    required this.distributorName,
  });

  @override
  State<ManagerSlotsBookingScreen> createState() =>
      _ManagerSlotsBookingScreenState();
}

class _ManagerSlotsBookingScreenState extends State<ManagerSlotsBookingScreen> {
  bool loading = false;
  String selectedDate = _today();

  List<SlotItem> slots = [];
  SlotRules rules = SlotRules(maxAmount: 80000, lastSlotEnabled: false, lastSlotOpenAfter: "17:00");

  static String _today() {
    final now = DateTime.now();
    return "${now.year.toString().padLeft(4, "0")}-${now.month.toString().padLeft(2, "0")}-${now.day.toString().padLeft(2, "0")}";
  }

  List<String> allowedDates() {
    final now = DateTime.now();
    final tomorrow = now.add(const Duration(days: 1));
    return [
      "${now.year.toString().padLeft(4, "0")}-${now.month.toString().padLeft(2, "0")}-${now.day.toString().padLeft(2, "0")}",
      "${tomorrow.year.toString().padLeft(4, "0")}-${tomorrow.month.toString().padLeft(2, "0")}-${tomorrow.day.toString().padLeft(2, "0")}",
    ];
  }

  void toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadGrid();
    });
  }

  Future<String> _companyCode() async {
    final scope = TickinAppScope.of(context);
    final userJson = await scope.tokenStore.getUserJson();
    if (userJson != null && userJson.isNotEmpty) {
      final u = jsonDecode(userJson);
      final cid = (u["companyId"] ?? u["companyCode"] ?? "").toString();
      return cid.contains("#") ? cid.split("#").last : cid;
    }
    return "VAGR_IT";
  }

  Future<void> _loadGrid() async {
    setState(() => loading = true);
    try {
      final scope = TickinAppScope.of(context);
      final companyCode = await _companyCode();

      final res = await scope.slotsApi.getGrid(
        companyCode: companyCode,
        date: selectedDate,
      );

      final list = (res["slots"] ?? []) as List;
      final parsedSlots = list
          .whereType<Map>()
          .map((e) => SlotItem.fromMap(e.cast<String, dynamic>()))
          .toList();

      final rulesMap = (res["rules"] ?? {}) as Map;
      final parsedRules =
          SlotRules.fromMap(rulesMap.cast<String, dynamic>());

      setState(() {
        slots = parsedSlots;
        rules = parsedRules;
      });
    } catch (e) {
      toast("❌ Grid load failed: $e");
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  /// ✅ Manager threshold edit dialog
  Future<void> _editThreshold() async {
    final scope = TickinAppScope.of(context);
    final companyCode = await _companyCode();

    final ctrl = TextEditingController(text: rules.maxAmount.toStringAsFixed(0));

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Update Threshold"),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: "Threshold Amount"),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("Cancel")),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text("Update")),
        ],
      ),
    );

    if (ok != true) return;

    final newVal = double.tryParse(ctrl.text.trim()) ?? rules.maxAmount;

    try {
      await scope.slotsApi.managerSetGlobalMax({
        "companyCode": companyCode,
        "maxAmount": newVal,
      });
      toast("✅ Threshold Updated");
      await _loadGrid();
    } catch (e) {
      toast("❌ Failed: $e");
    }
  }

  /// ✅ Manager toggle last slot (night slot)
  Future<void> _toggleNightSlot(bool enabled) async {
    try {
      final scope = TickinAppScope.of(context);
      final companyCode = await _companyCode();

      await scope.slotsApi.toggleLastSlot({
        "companyCode": companyCode,
        "enabled": enabled,
        "openAfter": rules.lastSlotOpenAfter,
      });

      toast(enabled ? "✅ Night Slot Opened" : "✅ Night Slot Closed");
      await _loadGrid();
    } catch (e) {
      toast("❌ Toggle failed: $e");
    }
  }

  /// ✅ slot tap handler
  Future<void> _onSlotTap(SlotItem slot) async {
    if (slot.normalizedStatus == "DISABLED") {
      // enable slot
      await _enableSlot(slot);
      return;
    }

    if (slot.isBooked) {
      await _cancelSlot(slot);
      return;
    }

    // if available -> book
    await _bookSlot(slot);
  }

  Future<void> _bookSlot(SlotItem slot) async {
    try {
      final scope = TickinAppScope.of(context);
      final companyCode = await _companyCode();

      if (slot.vehicleType.toUpperCase() != "FULL") {
        toast("Manager screen only books FULL slots directly");
        return;
      }

      if (slot.pos == null) {
        toast("Slot position missing");
        return;
      }

      await scope.slotsApi.book(
        companyCode: companyCode,
        date: selectedDate,
        time: slot.time,
        pos: slot.pos,
        distributorCode: widget.distributorCode,
        distributorName: widget.distributorName,
        amount: rules.maxAmount + 1, // force FULL booking
        orderId: "MANAGER_BOOK_${DateTime.now().millisecondsSinceEpoch}",
      );

      toast("✅ Slot booked");
      await _loadGrid();
    } catch (e) {
      toast("❌ Book failed: $e");
    }
  }

  Future<void> _cancelSlot(SlotItem slot) async {
    try {
      final scope = TickinAppScope.of(context);
      final companyCode = await _companyCode();

      if (slot.pos == null || slot.userId == null) {
        toast("Cancel requires pos + userId");
        return;
      }

      await scope.slotsApi.managerCancelBooking({
        "companyCode": companyCode,
        "date": selectedDate,
        "time": slot.time,
        "pos": slot.pos,
        "userId": slot.userId,
      });

      toast("✅ Booking cancelled");
      await _loadGrid();
    } catch (e) {
      toast("❌ Cancel failed: $e");
    }
  }

  Future<void> _disableSlot(SlotItem slot) async {
    try {
      final scope = TickinAppScope.of(context);
      final companyCode = await _companyCode();

      await scope.slotsApi.managerDisableSlot({
        "companyCode": companyCode,
        "date": selectedDate,
        "time": slot.time,
        "pos": slot.pos,
        "vehicleType": "FULL",
      });

      toast("✅ Slot disabled");
      await _loadGrid();
    } catch (e) {
      toast("❌ Disable failed: $e");
    }
  }

  Future<void> _enableSlot(SlotItem slot) async {
    try {
      final scope = TickinAppScope.of(context);
      final companyCode = await _companyCode();

      await scope.slotsApi.managerEnableSlot({
        "companyCode": companyCode,
        "date": selectedDate,
        "time": slot.time,
        "pos": slot.pos,
        "vehicleType": "FULL",
      });

      toast("✅ Slot enabled");
      await _loadGrid();
    } catch (e) {
      toast("❌ Enable failed: $e");
    }
  }

  List<SlotItem> _sessionSlots(String session) {
    // session times grouping
    final times = <String>[];

    if (session == "Morning") times.addAll(["09:00"]);
    if (session == "Afternoon") times.addAll(["12:30"]);
    if (session == "Evening") times.addAll(["16:00"]);
    if (session == "Night") times.addAll(["20:00"]);

    return slots.where((s) => times.contains(s.time)).toList();
  }

  Widget _sessionSection(String title) {
    final list = _sessionSlots(title);

    if (title == "Night" && rules.lastSlotEnabled == false) {
      return const SizedBox.shrink();
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: const Color(0xFF0B1C2D),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: SizedBox(
          height: 240,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: Colors.white)),
              const SizedBox(height: 10),
              Expanded(
                child: SlotGrid(
                  slots: list,
                  role: "MANAGER",
                  myDistributorCode: widget.distributorCode,
                  onSlotTap: _onSlotTap,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                "Tip: Tap slot to book/cancel. Long press to disable.",
                style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF06121F),
      appBar: AppBar(
        title: const Text("Manager Slot Booking"),
        actions: [
          DropdownButton<String>(
            value: selectedDate,
            dropdownColor: Colors.black,
            underline: const SizedBox(),
            items: allowedDates()
                .map((d) => DropdownMenuItem(value: d, child: Text(d)))
                .toList(),
            onChanged: (v) async {
              if (v == null) return;
              setState(() => selectedDate = v);
              await _loadGrid();
            },
          ),
          IconButton(onPressed: _loadGrid, icon: const Icon(Icons.refresh))
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  color: const Color(0xFF0B1C2D),
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              "Threshold: ₹${rules.maxAmount.toStringAsFixed(0)}",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                            const Spacer(),
                            TextButton(
                              onPressed: _editThreshold,
                              child: const Text("CHANGE",
                                  style: TextStyle(color: Colors.lightBlue)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Text(
                              "Night Slot: ${rules.lastSlotEnabled ? "OPEN" : "CLOSED"} (After ${rules.lastSlotOpenAfter})",
                              style: const TextStyle(color: Colors.white70),
                            ),
                            const Spacer(),
                            Switch(
                              value: rules.lastSlotEnabled,
                              onChanged: _toggleNightSlot,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                _sessionSection("Morning"),
                _sessionSection("Afternoon"),
                _sessionSection("Evening"),
                _sessionSection("Night"),
              ],
            ),
    );
  }
}
