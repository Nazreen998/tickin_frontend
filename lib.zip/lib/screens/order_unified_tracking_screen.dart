import 'package:flutter/material.dart';

class OrderUnifiedTrackingScreen extends StatelessWidget {
  final String orderId;
  const OrderUnifiedTrackingScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tracking $orderId")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          ListTile(
            leading: Icon(Icons.check_circle, color: Colors.green),
            title: Text("Slot Booked"),
          ),
          ListTile(
            leading: Icon(Icons.check_circle, color: Colors.green),
            title: Text("Loading Started"),
          ),
          ListTile(
            leading: Icon(Icons.radio_button_unchecked),
            title: Text("Driver Assigned"),
          ),
        ],
      ),
    );
  }
}
