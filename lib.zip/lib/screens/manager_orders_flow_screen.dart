import 'package:flutter/material.dart';
import '../app_scope.dart';

class ManagerOrderFlowScreen extends StatefulWidget {
  final String flowKey;
  final String orderId;

  const ManagerOrderFlowScreen({
    super.key,
    required this.flowKey,
    required this.orderId,
  });

  @override
  State<ManagerOrderFlowScreen> createState() => _ManagerOrderFlowScreenState();
}

class _ManagerOrderFlowScreenState extends State<ManagerOrderFlowScreen> {
  bool loading = false;
  Map<String, dynamic>? flow;

  @override
  void initState() {
    super.initState();
    _loadFlow();
  }

  void toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _loadFlow() async {
    setState(() => loading = true);
    try {
      final scope = TickinAppScope.of(context);

      // ✅ GET /api/orders/flow/:flowKey
      final res = await scope.httpClient.get("/api/orders/flow/${widget.flowKey}");
      setState(() {
        flow = (res["flow"] ?? res["data"] ?? res) as Map<String, dynamic>?;
      });
    } catch (e) {
      toast("❌ Flow load failed: $e");
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _postAction(String path, Map<String, dynamic> body) async {
    setState(() => loading = true);
    try {
      final scope = TickinAppScope.of(context);
      final res = await scope.httpClient.post(path, body: body);

      if (res["ok"] == false) {
        throw Exception(res["message"] ?? "Action failed");
      }

      toast("✅ Updated");
      await _loadFlow();
    } catch (e) {
      toast("❌ $e");
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final steps = (flow?["steps"] ?? flow?["timeline"] ?? []) as List;

    return Scaffold(
      appBar: AppBar(
        title: Text("Order Flow (${widget.orderId})"),
        actions: [
          IconButton(onPressed: _loadFlow, icon: const Icon(Icons.refresh))
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : flow == null
              ? const Center(child: Text("No flow data"))
              : ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("FlowKey: ${widget.flowKey}",
                                style: const TextStyle(fontWeight: FontWeight.bold)),
                            const SizedBox(height: 6),
                            Text("Status: ${(flow?["status"] ?? "").toString()}"),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),

                    // ✅ Buttons
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        ElevatedButton(
                          onPressed: () => _postAction(
                            "/api/orders/loading-start",
                            {"flowKey": widget.flowKey},
                          ),
                          child: const Text("Loading Start"),
                        ),
                        ElevatedButton(
                          onPressed: () => _postAction(
                            "/api/orders/loading-end",
                            {"flowKey": widget.flowKey},
                          ),
                          child: const Text("Loading End"),
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            final driverId = await _askText("Enter Driver ID");
                            if (driverId == null || driverId.isEmpty) return;
                            await _postAction(
                              "/api/orders/assign-driver",
                              {"flowKey": widget.flowKey, "driverId": driverId},
                            );
                          },
                          child: const Text("Assign Driver"),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),
                    const Text("Timeline",
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(height: 10),

                    ...steps.map((s) {
                      final m = s is Map ? s : {};
                      final title = (m["title"] ?? m["status"] ?? "").toString();
                      final time = (m["time"] ?? m["at"] ?? "").toString();
                      final note = (m["note"] ?? m["message"] ?? "").toString();

                      return ListTile(
                        leading: const Icon(Icons.check_circle_outline),
                        title: Text(title),
                        subtitle: Text("$time\n$note"),
                      );
                    }).toList(),
                  ],
                ),
    );
  }

  Future<String?> _askText(String title) async {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, decoration: const InputDecoration(hintText: "Type here")),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, c.text.trim()),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }
}
