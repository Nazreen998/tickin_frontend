// ignore_for_file: deprecated_member_use, unused_import, prefer_iterable_wheretype

import 'package:flutter/material.dart';
import '../app_scope.dart';
import 'order_details_screen.dart';
import 'slots/manager_slots_booking_screen.dart';

class ManagerAllOrdersScreen extends StatefulWidget {
  const ManagerAllOrdersScreen({super.key});

  @override
  State<ManagerAllOrdersScreen> createState() => _ManagerAllOrdersScreenState();
}

class _ManagerAllOrdersScreenState extends State<ManagerAllOrdersScreen> {
  bool loading = false;
  List<Map<String, dynamic>> orders = [];
  String selectedStatus = "CONFIRMED";
  bool _loadedOnce = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_loadedOnce) {
      _loadedOnce = true;
      _load();
    }
  }

  void toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final scope = TickinAppScope.of(context);

      final res = await scope.ordersApi.all(status: selectedStatus);

      dynamic raw = res["orders"] ?? res["items"] ?? res["data"] ?? res;

      // ✅ If raw is Map, extract list inside
      if (raw is Map) {
        raw = raw["orders"] ?? raw["items"] ?? raw["data"] ?? [];
      }

      // ✅ Ensure list type
      final list = raw is List ? raw : [];

      setState(() {
        orders = list
            .where((e) => e is Map)
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList();
      });
    } catch (e) {
      toast("❌ Load failed: $e");
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String _safe(Map o, List<String> keys) {
    for (final k in keys) {
      if (o[k] != null && o[k].toString().isNotEmpty) return o[k].toString();
    }
    return "-";
  }

  num _num(dynamic v) {
    if (v == null) return 0;
    if (v is num) return v;
    return num.tryParse(v.toString()) ?? 0;
  }

  Future<void> _openSlotBooking(Map<String, dynamic> o) async {
    final distCode =
        (o["distributorId"] ?? o["distributorCode"] ?? "").toString();
    final distName = (o["distributorName"] ?? o["agencyName"] ?? "").toString();

    if (distCode.isEmpty || distName.isEmpty) {
      toast("❌ Distributor details missing");
      return;
    }

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ManagerSlotsBookingScreen(
          distributorCode: distCode,
          distributorName: distName,
        ),
      ),
    );

    await _load(); // refresh after slot booking
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("All Orders (Manager)"),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: DropdownButtonFormField<String>(
              value: selectedStatus,
              decoration: const InputDecoration(
                labelText: "Status Filter",
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(value: "CONFIRMED", child: Text("CONFIRMED")),
                DropdownMenuItem(value: "PENDING", child: Text("PENDING")),
                DropdownMenuItem(value: "DRAFT", child: Text("DRAFT")),
                DropdownMenuItem(value: "CANCELLED", child: Text("CANCELLED")),
              ],
              onChanged: (v) async {
                if (v == null) return;
                setState(() => selectedStatus = v);
                await _load();
              },
            ),
          ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : orders.isEmpty
                    ? const Center(child: Text("No orders found"))
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.builder(
                          itemCount: orders.length,
                          itemBuilder: (_, i) {
                            final o = orders[i];

                            final orderId = _safe(o, ["orderId", "id"]);
                            final status = _safe(o, ["status"]);
                            final dist = _safe(o, [
                              "distributorName",
                              "agencyName",
                              "distributorId"
                            ]);

                            final amount = _num(o["amount"] ??
                                o["totalAmount"] ??
                                o["grandTotal"]);
                            final createdAt =
                                _safe(o, ["createdAt", "created_at", "date"]);

                            return Card(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              child: ListTile(
                                title: Text(dist),
                                subtitle: Text(
                                    "Order: $orderId\nStatus: $status\nDate: $createdAt"),
                                trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "₹${amount.toStringAsFixed(2)}",
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                    const SizedBox(height: 6),
                                    const Text("SLOT BOOK",
                                        style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.blue)),
                                  ],
                                ),
                                // ✅ CLICK -> Slot Booking screen
                                onTap: () => _openSlotBooking(o),

                                // ✅ Long press -> order details (optional)
                                onLongPress: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) =>
                                          OrderDetailsScreen(orderId: orderId),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
