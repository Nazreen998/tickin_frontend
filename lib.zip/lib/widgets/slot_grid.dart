import 'package:flutter/material.dart';
import '../models/slot_models.dart';

class SlotGrid extends StatelessWidget {
  final List<SlotItem> slots;
  final void Function(SlotItem slot) onSlotTap;

  // ✅ role control
  final String role; // MANAGER / SALES / DISTRIBUTOR
  final String? myDistributorCode;

  const SlotGrid({
    super.key,
    required this.slots,
    required this.onSlotTap,
    required this.role,
    this.myDistributorCode,
  });

  bool get isManager => role.toUpperCase() == "MANAGER";

  @override
  Widget build(BuildContext context) {
    if (slots.isEmpty) {
      return const Center(
        child: Text("No slots", style: TextStyle(color: Colors.white70)),
      );
    }

    // ✅ Sort by slotId order (3001..)
    final list = [...slots];
    list.sort((a, b) => (a.slotIdNum).compareTo(b.slotIdNum));

    return GridView.builder(
      itemCount: list.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.05,
      ),
      itemBuilder: (_, i) {
        final slot = list[i];
        return _SlotTile(
          slot: slot,
          role: role,
          myDistributorCode: myDistributorCode,
          onTap: () => onSlotTap(slot),
        );
      },
    );
  }
}

class _SlotTile extends StatelessWidget {
  final SlotItem slot;
  final VoidCallback onTap;
  final String role;
  final String? myDistributorCode;

  const _SlotTile({
    required this.slot,
    required this.onTap,
    required this.role,
    required this.myDistributorCode,
  });

  bool get isManager => role.toUpperCase() == "MANAGER";

  Color _bg() {
    final st = slot.normalizedStatus;

    if (st == "DISABLED") return Colors.grey.shade700;
    if (st == "BOOKED") return Colors.red.shade700;

    // ✅ waiting/pending states
    if (st.contains("PENDING") ||
        st.contains("WAIT") ||
        (slot.isMerge &&
            (slot.tripStatus?.toUpperCase().contains("PARTIAL") == true ||
                slot.tripStatus?.toUpperCase().contains("READY") == true))) {
      return Colors.orange.shade700;
    }

    return Colors.green.shade700;
  }

  String _label() {
    final st = slot.normalizedStatus;

    if (st == "DISABLED") return "DISABLED";
    if (st == "BOOKED") return "BOOKED";

    if (st.contains("PENDING") || st.contains("WAIT")) return "WAITING";

    if (slot.isMerge && slot.tripStatus != null) {
      final ts = slot.tripStatus!.toUpperCase();
      if (ts.contains("READY")) return "READY";
      if (ts.contains("PARTIAL")) return "WAITING";
      if (ts.contains("FULL")) return "BOOKED";
    }

    return "AVAILABLE";
  }

  bool _canShowDistributorName() {
    // ✅ Manager sees all names
    if (isManager) return true;

    // ✅ For distributor/sales: only show if belongs to him
    if (myDistributorCode == null) return false;
    return slot.distributorCode == myDistributorCode;
  }

  @override
  Widget build(BuildContext context) {
    final label = _label();
    final canShowName = _canShowDistributorName();

    final distName = (slot.distributorName ?? "").trim();

    final showName = canShowName && (label == "WAITING" || label == "BOOKED" || label == "READY");

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: _bg(),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // ✅ SlotId
            Text(
              "Slot ${slot.slotIdLabel}",
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),

            const SizedBox(height: 10),

            // ✅ Status label only (NO time)
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),

            // ✅ Distributor name only for WAITING / BOOKED
            if (showName) ...[
              const SizedBox(height: 10),
              Text(
                distName.isEmpty ? "-" : distName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
