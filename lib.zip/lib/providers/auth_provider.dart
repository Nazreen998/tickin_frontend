import 'dart:convert';
import '../storage/token_store.dart';
import '../models/app_user.dart';

class AuthProvider {
  final TokenStore tokenStore;
  AppUser? _cachedUser;

  AuthProvider(this.tokenStore);

  Future<AppUser?> getCurrentUser({bool forceRefresh = false}) async {
    if (_cachedUser != null && !forceRefresh) return _cachedUser;

    final userJson = await tokenStore.getUserJson();
    _cachedUser = AppUser.fromJsonString(userJson);
    return _cachedUser;
  }

  Future<String?> getRole() async {
    final u = await getCurrentUser();
    return u?.role;
  }

  Future<String?> getDistributorCode() async {
    final u = await getCurrentUser();
    return u?.distributorCode;
  }

  /// ✅ use this after login API success
  Future<void> setSession({
    required String token,
    required Map<String, dynamic> userMap,
  }) async {
    await tokenStore.saveToken(token);
    await tokenStore.saveUserJson(jsonEncode(userMap));
    _cachedUser = AppUser.fromJsonString(jsonEncode(userMap));
  }

  Future<void> clear() async {
    _cachedUser = null;
    await tokenStore.clear();
  }
}
