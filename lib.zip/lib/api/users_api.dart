import '../api/http_client.dart';
import '../config/api_config.dart';

class UsersApi {
  final HttpClient client;
  UsersApi(this.client);

  /// GET /users/drivers
  Future<Map<String, dynamic>> getDrivers() {
    return client.get("${ApiConfig.users}/drivers");
  }

  /// alias (if old code uses drivers())
  Future<Map<String, dynamic>> drivers() => getDrivers();

  /// Driver dropdown helper
  Future<List<Map<String, dynamic>>> driverDropdown() async {
  final res = await getDrivers();
  final list = (res["drivers"] ?? []) as List;
  return list.map((e) => Map<String, dynamic>.from(e)).toList();
}

}
