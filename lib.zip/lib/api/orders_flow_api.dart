import '../api/http_client.dart';
import '../config/api_config.dart';

class OrdersFlowApi {
  final HttpClient client;
  OrdersFlowApi(this.client);

  /// ✅ Slot-confirmed trips list (Grouped)
  /// Backend requires date query
  Future<Map<String, dynamic>> slotConfirmedOrders({required String date}) {
    return client.get("${ApiConfig.orders}/slot-confirmed?date=$date");
  }

  /// ✅ Get order flow by flowKey (mergeKey OR orderId)
  Future<Map<String, dynamic>> getOrderFlowByKey(String flowKey) {
    return client.get("${ApiConfig.orders}/flow/$flowKey");
  }

  /// ✅ Vehicle selected (mergeKey/orderId supported via flowKey param)
  Future<Map<String, dynamic>> vehicleSelected(String flowKey, String vehicleType) {
    return client.post(
      "${ApiConfig.orders}/vehicle-selected/$flowKey",
      body: {"vehicleType": vehicleType},
    );
  }

  /// ✅ Loading start (send flowKey only)
  Future<Map<String, dynamic>> loadingStart(String flowKey) {
    return client.post(
      "${ApiConfig.orders}/loading-start",
      body: {"flowKey": flowKey},
    );
  }

  /// ✅ Loading end (send flowKey only)
  Future<Map<String, dynamic>> loadingEnd(String flowKey) {
    return client.post(
      "${ApiConfig.orders}/loading-end",
      body: {"flowKey": flowKey},
    );
  }

  /// ✅ Assign driver (send flowKey only)
  Future<Map<String, dynamic>> assignDriver({
    required String flowKey,
    required String driverId,
    String? vehicleNo,
  }) {
    return client.post("${ApiConfig.orders}/assign-driver", body: {
      "flowKey": flowKey,
      "driverId": driverId,
      if (vehicleNo != null) "vehicleNo": vehicleNo,
    });
  }
}
