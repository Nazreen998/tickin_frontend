import 'dart:convert';
import 'package:http/http.dart' as http;
import '../storage/token_store.dart';
import '../config/api_config.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class HttpClient {
  final TokenStore tokenStore;

  HttpClient(this.tokenStore);

  Uri _uri(String path, [Map<String, dynamic>? query]) {
    return Uri.parse("${ApiConfig.baseUrl}$path")
        .replace(queryParameters: query);
  }

  Future<Map<String, dynamic>> get(
    String path, {
    Map<String, dynamic>? query,
  }) async {
    final res = await http.get(
      _uri(path, query),
      headers: await _headers(),
    );
    return _handle(res);
  }

  Future<Map<String, dynamic>> post(
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final res = await http.post(
      _uri(path),
      headers: await _headers(),
      body: jsonEncode(body ?? {}),
    );
    return _handle(res);
  }

  Future<Map<String, dynamic>> patch(
    String path, {
    Map<String, dynamic>? body,
  }) async {
    final res = await http.patch(
      _uri(path),
      headers: await _headers(),
      body: jsonEncode(body ?? {}),
    );
    return _handle(res);
  }

  Future<Map<String, dynamic>> delete(String path) async {
    final res = await http.delete(
      _uri(path),
      headers: await _headers(),
    );
    return _handle(res);
  }

  /// ✅ Token added automatically (except when empty)
  Future<Map<String, String>> _headers() async {
    final token = await tokenStore.getToken();

    final headers = <String, String>{
      "Content-Type": "application/json",
    };

    if (token != null && token.isNotEmpty) {
      headers["Authorization"] = "Bearer $token";
    }

    return headers;
  }

  Map<String, dynamic> _handle(http.Response res) {
    final body = res.body.isNotEmpty
        ? jsonDecode(res.body)
        : <String, dynamic>{};

    if (res.statusCode >= 200 && res.statusCode < 300) {
      return body is Map<String, dynamic> ? body : {"data": body};
    }

    final msg =
        body["message"] ?? body["error"] ?? "Request failed";
    throw ApiException(msg.toString());
  }
}
