import '../api/http_client.dart';

class OrdersApi {
  final HttpClient client;
  OrdersApi(this.client);

  /// ✅ Backend route base is fixed:
  /// /api/orders (confirmed from orders.routes.js)
  static const String _b = "/api/orders";

  Future<Map<String, dynamic>> createOrder({
    required String distributorId,
    required String distributorName,
    required List<Map<String, dynamic>> items,
  }) {
    return client.post("$_b/create", body: {
      "distributorId": distributorId,
      "distributorName": distributorName,
      "items": items,
    });
  }

  Future<Map<String, dynamic>> confirmDraft(String orderId) {
    return client.post("$_b/confirm-draft/$orderId");
  }

  Future<Map<String, dynamic>> confirmOrder({
    required String orderId,
    required String companyCode,
    Map<String, dynamic>? slot,
  }) {
    return client.post("$_b/confirm/$orderId", body: {
      "companyCode": companyCode,
      if (slot != null) "slot": slot,
    });
  }

  Future<Map<String, dynamic>> updateItems({
    required String orderId,
    required List<Map<String, dynamic>> items,
  }) {
    return client.patch("$_b/update/$orderId", body: {"items": items});
  }

  Future<Map<String, dynamic>> cancelOrder(String orderId) {
    return client.delete("$_b/$orderId");
  }

  Future<Map<String, dynamic>> getOrderById(String orderId) {
    return client.get("$_b/$orderId");
  }

  Future<Map<String, dynamic>> pending() {
    return client.get("$_b/pending");
  }

  Future<Map<String, dynamic>> today() {
    return client.get("$_b/today");
  }

  Future<Map<String, dynamic>> delivery() {
    return client.get("$_b/delivery");
  }

  Future<Map<String, dynamic>> all({String? status}) {
    return client.get("$_b/all",
        query: status == null ? null : {"status": status});
  }

  Future<Map<String, dynamic>> my() {
    return client.get("$_b/my");
  }

  /// ✅ Always confirm: Draft -> confirm-draft, Pending -> confirm
  Future<Map<String, dynamic>> placePendingThenConfirmDraftIfAny({
    required String distributorId,
    required String distributorName,
    required List<Map<String, dynamic>> items,
    String? companyCode,
  }) async {
    final created = await createOrder(
      distributorId: distributorId,
      distributorName: distributorName,
      items: items,
    );

    if (created["ok"] == false) {
      throw ApiException(created["message"] ?? "Create order failed");
    }

    final orderId = (created["orderId"] ?? "").toString();
    final status = (created["status"] ?? "").toString().toUpperCase();

    if (orderId.isEmpty) {
      throw ApiException("orderId missing in create response");
    }

    // ✅ Confirm Draft
    if (status == "DRAFT") {
      final confirmed = await confirmDraft(orderId);

      if (confirmed["ok"] == false) {
        throw ApiException(confirmed["message"] ?? "Confirm draft failed");
      }

      final finalStatus =
          (confirmed["status"] ?? "CONFIRMED").toString().toUpperCase();

      if (finalStatus != "CONFIRMED") {
        throw ApiException("Order not confirmed. status=$finalStatus");
      }

      return {
        ...created,
        "status": "CONFIRMED",
        "message": confirmed["message"] ?? created["message"],
      };
    }

    // ✅ Confirm Pending
    if (status == "PENDING") {
      if (companyCode == null || companyCode.isEmpty) {
        throw ApiException("companyCode missing to confirm PENDING order");
      }

      final confirmed =
          await confirmOrder(orderId: orderId, companyCode: companyCode);

      if (confirmed["ok"] == false) {
        throw ApiException(confirmed["message"] ?? "Confirm order failed");
      }

      final finalStatus =
          (confirmed["status"] ?? "CONFIRMED").toString().toUpperCase();

      if (finalStatus != "CONFIRMED") {
        throw ApiException("Order not confirmed. status=$finalStatus");
      }

      return {
        ...created,
        "status": "CONFIRMED",
        "message": confirmed["message"] ?? created["message"],
      };
    }

    // ✅ Already confirmed
    if (status != "CONFIRMED") {
      throw ApiException("Unexpected status=$status");
    }

    return created;
  }
}
